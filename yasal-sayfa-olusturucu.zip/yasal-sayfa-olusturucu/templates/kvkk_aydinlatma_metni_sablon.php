<?php
return <<<EOT
<h2>KİŞİSEL VERİLERİN KORUNMASI KANUNU (“KVKK”) AYDINLATMA METNİ</h2>

<p><strong>{{firma_adi}}</strong> olarak, 6698 sayılı Kişisel Verilerin Korunması Kanunu (“KVKK”) kapsamında, kişisel verilerinizin işlenmesine ilişkin sizleri bilgilendirmek isteriz.</p>

<h3>1. Veri Sorumlusu</h3>
<p>Kişisel verileriniz, veri sorumlusu sıfatıyla <strong>{{firma_adi}}</strong> tarafından işlenmektedir. İletişim bilgileri:</p>
<ul>
<li><strong>Adres:</strong> {{adres}}</li>
<li><strong>E-posta:</strong> {{email}}</li>
<li><strong>Telefon:</strong> {{telefon}}</li>
<li><strong>Web Sitesi:</strong> {{site}}</li>
</ul>

<h3>2. Kişisel Verilerin İşlenme Amaçları</h3>
<p>Tarafımızca işlenen kişisel verileriniz aşağıdaki amaçlarla kullanılmaktadır:</p>
<ul>
<li>Ürün ve hizmetlerin sunulması ve sipariş süreçlerinin yürütülmesi</li>
<li>Müşteri ilişkileri yönetimi ve destek hizmetleri</li>
<li>İlgili mevzuatlar kapsamında ticari kayıtların tutulması</li>
<li>Elektronik ticari iletilerin gönderimi (onay vermeniz durumunda)</li>
<li>Kampanya ve promosyon bilgilendirmeleri</li>
<li>Ürün teslimatı, fatura gönderimi ve iade süreçleri</li>
</ul>

<h3>3. İşlenen Kişisel Veriler</h3>
<p>İşlenen veriler, sipariş, üyelik ve iletişim formları aracılığıyla elde edilen:</p>
<ul>
<li>Ad soyad, T.C. kimlik no, e-posta, telefon numarası</li>
<li>Adres ve teslimat bilgileri</li>
<li>Ödeme bilgileri (ödeme aracı, kart tipi, işlem detayları)</li>
<li>İşlem geçmişi, sipariş detayları, IP adresi, çerez kayıtları</li>
</ul>

<h3>4. Kişisel Verilerin Aktarılması</h3>
<p>Kişisel verileriniz, aşağıdaki amaçlarla yurt içindeki üçüncü kişilere aktarılabilir:</p>
<ul>
<li>Hukuki yükümlülükler gereği resmi kurum ve kuruluşlara</li>
<li>Kargo ve lojistik firmalarına ürün teslimatı amacıyla</li>
<li>Hizmet sağlayıcılarımıza (barındırma, yazılım ve çağrı merkezi hizmetleri)</li>
<li>Mali müşavirler ve denetim firmaları gibi danışmanlara</li>
</ul>

<h3>5. Toplama Yöntemi ve Hukuki Sebep</h3>
<p>Kişisel verileriniz, elektronik ticaret faaliyetleri kapsamında; internet sitesi, çağrı merkezi, mobil uygulama, sosyal medya hesapları, e-posta yazışmaları ve fiziki formlar aracılığıyla toplanır. KVKK’nın 5. ve 6. maddelerinde belirtilen hukuki sebepler doğrultusunda işlenmektedir.</p>

<h3>6. Veri Sahibi Olarak Haklarınız</h3>
<p>KVKK’nın 11. maddesi kapsamında veri sahipleri olarak aşağıdaki haklara sahipsiniz:</p>
<ul>
<li>Kişisel verinizin işlenip işlenmediğini öğrenme</li>
<li>İşlenmişse buna ilişkin bilgi talep etme</li>
<li>İşlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme</li>
<li>Yurt içinde veya yurt dışında verilerin aktarıldığı 3. kişileri bilme</li>
<li>Eksik veya yanlış işlenmişse düzeltilmesini isteme</li>
<li>KVKK’ya aykırı olarak işlenmişse silinmesini veya yok edilmesini isteme</li>
<li>Bu işlemlerin üçüncü kişilere bildirilmesini isteme</li>
<li>Otomatik sistemlerle analiz edilmesi nedeniyle aleyhe bir sonuç çıkmasına itiraz etme</li>
<li>Verilerin kanuna aykırı işlenmesi sebebiyle zarara uğranması hâlinde zararın giderilmesini talep etme</li>
</ul>

<h3>7. Başvuru Yöntemi</h3>
<p>Kişisel verilerinize ilişkin taleplerinizi <strong>{{email}}</strong> adresine e-posta göndererek veya yazılı olarak <strong>{{adres}}</strong> adresine başvurarak iletebilirsiniz.</p>

<p>İşbu Aydınlatma Metni {{tarih}} tarihinde güncellenmiştir.</p>
EOT;
