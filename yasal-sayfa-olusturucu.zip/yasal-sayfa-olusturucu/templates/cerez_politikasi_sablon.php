<?php
return <<<EOT
<h2>ÇEREZ POLİTİKASI</h2>

<p><strong>{{firma_adi}}</strong> olarak, internet sitemizde çerez (cookie) kullanmaktayız. Bu Çerez Politikası, sitemizi ziyaret ettiğinizde tarayıcınıza yerleştirilen çerezlerin türleri, kullanım amaçları ve çerezleri nasıl kontrol edebileceğinize dair bilgi sunmak amacıyla hazırlanmıştır.</p>

<h3>1. Çerez Nedir?</h3>
<p>Çerezler, internet siteleri tarafından tarayıcınız aracılığıyla cihazınıza depolanan küçük metin dosyalarıdır. Bu dosyalar, internet sitesinin sizi hatırlamasını ve deneyiminizi geliştirmesini sağlar.</p>

<h3>2. Kullanılan Çerez Türleri</h3>
<p>Web sitemizde aşağıdaki türde çerezler kullanılmaktadır:</p>
<ul>
<li><strong>Kesinlikle Gerekli Çerezler:</strong> Sitenin düzgün şekilde çalışabilmesi için gereklidir. Alışveriş sepeti, giriş işlemleri gibi temel fonksiyonları sağlar.</li>
<li><strong>İşlevsellik Çerezleri:</strong> Site tercihlerinizin (dil, lokasyon vs.) hatırlanmasını sağlar.</li>
<li><strong>Performans ve Analitik Çerezleri:</strong> Ziyaretçi sayısı, hangi sayfaların ziyaret edildiği gibi anonim istatistiksel verileri toplar.</li>
<li><strong>Hedefleme / Reklam Çerezleri:</strong> İlgi alanlarınıza göre reklam göstermek amacıyla üçüncü taraflarca yerleştirilen çerezlerdir.</li>
</ul>

<h3>3. Çerezlerin Toplanma Amacı</h3>
<p>Çerezler aşağıdaki amaçlarla toplanır:</p>
<ul>
<li>Site trafiğini analiz etmek ve performansı artırmak</li>
<li>Kullanıcı deneyimini iyileştirmek</li>
<li>Hedefli reklam ve kampanya sunabilmek</li>
<li>Sahteciliği önlemek ve güvenliği artırmak</li>
</ul>

<h3>4. Üçüncü Taraf Çerezler</h3>
<p>Web sitemizde, Google Analytics gibi üçüncü taraf hizmet sağlayıcılarına ait çerezler de kullanılabilir. Bu çerezler, ziyaretçiler hakkında anonim bilgiler toplar.</p>

<h3>5. Çerezleri Nasıl Kontrol Edebilirim?</h3>
<p>Tarayıcı ayarlarınız üzerinden çerezleri kontrol edebilir veya silebilirsiniz. Ancak çerezleri devre dışı bırakmanız durumunda, sitemizin bazı özelliklerinin düzgün çalışmayabileceğini unutmayın.</p>

<h3>6. Çerez Tercihlerinin Yönetimi</h3>
<p>İlk ziyaretinizde, çerez kullanımı hakkında bilgilendirme içeren bir çerez bildirimi görüntülenecektir. Buradan çerez tercihlerinizi yönetebilirsiniz.</p>

<h3>7. Güncellemeler</h3>
<p>Bu Çerez Politikası, {{tarih}} tarihinde güncellenmiştir. Çerez kullanımına ilişkin değişiklikler bu sayfadan duyurulacaktır.</p>

<p><strong>İletişim:</strong><br>
{{firma_adi}}<br>
Adres: {{adres}}<br>
E-posta: {{email}}<br>
Telefon: {{telefon}}<br>
Web: {{site}}</p>
EOT;
