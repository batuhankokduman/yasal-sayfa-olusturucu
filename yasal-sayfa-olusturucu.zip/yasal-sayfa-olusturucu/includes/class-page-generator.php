<?php

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class Yso_Page_Generator {

    /**
     * Sayfa oluşturma işlemi
     */
  public function create_selected_pages($selected_slugs) {
    $templates = [
        'mesafeli' => ['Mesafeli Satış Sözleşmesi', YSO_PATH . 'templates/mesafeli_satis_sozlesmesi_tasarimli.php'],
        'iade' => ['İade ve Değişim Politikası', YSO_PATH . 'templates/iade_ve_degisim_politikasi_sablon.php'],
        'gizlilik' => ['Gizlilik Politikası', YSO_PATH . 'templates/gizlilik.php'],
        'kvkk' => ['KVKK Aydınlatma Metni', YSO_PATH . 'templates/kvkk_aydinlatma_metni_sablon.php'],
        'cerez' => ['Çerez Politikası', YSO_PATH . 'templates/cerez_politikasi_sablon.php'],
        'kullanim' => ['Kullanım Koşulları', YSO_PATH . 'templates/kullanim_kosullari_sablon.php'],
    ];

    $created = [];

    foreach ($selected_slugs as $slug) {
        if (!isset($templates[$slug])) continue;
        list($title, $path) = $templates[$slug];

        if (!get_page_by_title($title)) {
            $content = file_exists($path) ? include $path : '';
            $content = strtr($content, [
                '{{firma_adi}}'      => get_option('yso_firma_adi'),
                '{{vkn}}'            => get_option('yso_vkn'),
                '{{vergi_dairesi}}'  => get_option('yso_vergi_dairesi'),
                '{{adres}}'          => get_option('yso_adres'),
                '{{email}}'          => get_option('yso_email'),
                '{{telefon}}'        => get_option('yso_telefon'),
                '{{site}}'           => get_option('yso_site'),
                '{{tarih}}'          => date('d.m.Y'),
            ]);

            wp_insert_post([
                'post_title'   => $title,
                'post_content' => $content,
                'post_status'  => 'publish',
                'post_type'    => 'page',
            ]);

            $created[] = $title;
        }
    }

    return empty($created) ? 'Seçilen tüm sayfalar zaten mevcut.' : 'Oluşturulan sayfalar: ' . implode(', ', $created);
}

}
