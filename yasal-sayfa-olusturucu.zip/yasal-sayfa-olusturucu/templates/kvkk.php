<?php
return <<<EOT
<h2>KVKK Aydınlatma Metni</h2>
<p>Bu metin, 6698 sayılı Kişisel Verilerin Korunması Kanunu kapsamında hazırlanmıştır...</p>
EOT;
