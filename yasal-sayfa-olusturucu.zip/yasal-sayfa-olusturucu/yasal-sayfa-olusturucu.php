<?php
/*
Plugin Name: Yasal Sayfa Oluşturucu
Description: Türkiye'deki web siteleri için gerekli yasal sayfaları tek tuşla oluşturur. AI desteklidir.
Version: 1.0.0
Author: Batuhan Kökduman
Author URI: https://wpacil.com
License: GPL2
Text Domain: yasal-sayfa
*/

if (!defined('ABSPATH')) exit; // Güvenlik önlemi

// Yükleme işlemleri
register_activation_hook(__FILE__, 'yso_activate_plugin');
function yso_activate_plugin() {
    // Gerekli ayarlar ve sayfaları oluşturmak için hazır
}

// Kaldırma işlemi için ayrı dosyada
register_uninstall_hook(__FILE__, 'yso_handle_uninstall');
function yso_handle_uninstall() {
    include plugin_dir_path(__FILE__) . 'uninstall.php';
}

define('YSO_PATH', plugin_dir_path(__FILE__));
define('YSO_URL', plugin_dir_url(__FILE__));

// Class'ları yükle
foreach (glob(YSO_PATH . 'includes/*.php') as $file) {
    require_once $file;
}

// Admin arayüzü başlat
if (is_admin()) {
    add_action('admin_menu', ['Yso_Admin_UI', 'init']);
}
require_once YSO_PATH . 'includes/class-settings.php';
Yso_Settings_Page::init();