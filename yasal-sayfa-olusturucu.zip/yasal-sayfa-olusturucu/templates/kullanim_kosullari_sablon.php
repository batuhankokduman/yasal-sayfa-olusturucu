<?php
return <<<EOT
<h2>KULLANIM KOŞULLARI</h2>

<p>Bu internet sitesi, <strong>{{firma_adi}}</strong> tarafından işletilmektedir. Siteyi ziyaret eden ve/veya kullanan her ziyaretçi, aşağıdaki kullanım koşullarını kabul etmiş sayılır.</p>

<h3>1. Genel Hükümler</h3>
<p>Web sitesine erişim sağlayarak, aşağıdaki şartları kabul etmiş sayılırsınız. Eğer bu koşulları kabul etmiyorsanız lütfen siteyi kullanmayınız.</p>

<h3>2. İçerik Kullanımı</h3>
<p>Site içerisinde sunulan metin, görsel, logo, grafik, yazılım ve benzeri tüm içerikler, <strong>{{firma_adi}}</strong>’nin mülkiyetindedir. Bu içeriklerin izinsiz kullanımı, çoğaltılması, dağıtılması yasaktır.</p>

<h3>3. Üyelik ve Hesap Güvenliği</h3>
<p>Sitemize üye olan kullanıcılar, hesap bilgilerini gizli tutmakla yükümlüdür. Hesapları üzerinden yapılan işlemlerden kullanıcılar sorumludur.</p>

<h3>4. Satın Alma ve Sipariş İşlemleri</h3>
<p>Web sitesi üzerinden yapılan tüm alışverişler, Mesafeli Satış Sözleşmesi ve Ön Bilgilendirme Formu hükümlerine tabidir. Sipariş onayı alınmadan ürün gönderimi yapılmaz.</p>

<h3>5. Kullanıcı Yükümlülükleri</h3>
<p>Kullanıcı, siteyi yasalara aykırı, zararlı veya dolandırıcılık amacıyla kullanamaz. Virüs, zararlı yazılım veya benzeri tehditler yayamaz.</p>

<h3>6. Üçüncü Taraf Bağlantılar</h3>
<p>Site, üçüncü taraf internet sitelerine bağlantılar içerebilir. Bu bağlantıların güvenilirliği ve içeriğinden <strong>{{firma_adi}}</strong> sorumlu değildir.</p>

<h3>7. Sorumluluğun Reddi</h3>
<p><strong>{{firma_adi}}</strong>, site içeriğindeki eksik ya da yanlış bilgilerden dolayı oluşabilecek doğrudan ya da dolaylı zararlardan sorumlu tutulamaz.</p>

<h3>8. Fikri Mülkiyet</h3>
<p>Site içeriği, Türk Fikir ve Sanat Eserleri Kanunu başta olmak üzere ilgili fikri haklar mevzuatı kapsamında korunmaktadır. Kullanıcılara, sadece kişisel kullanım için sınırlı bir lisans verilir.</p>

<h3>9. Değişiklikler</h3>
<p><strong>{{firma_adi}}</strong>, bu kullanım koşullarını dilediği zaman değiştirme hakkını saklı tutar. Güncellemeler {{tarih}} tarihinde geçerli olur.</p>

<h3>10. Uygulanacak Hukuk ve Yetkili Mahkeme</h3>
<p>İşbu Kullanım Koşulları, Türkiye Cumhuriyeti yasalarına tabidir. Tüm ihtilaflarda {{firma_adi}}’nın yerleşim yerindeki mahkemeler ve icra daireleri yetkilidir.</p>

<h3>İletişim</h3>
<p><strong>{{firma_adi}}</strong><br>
Adres: {{adres}}<br>
Telefon: {{telefon}}<br>
E-posta: {{email}}<br>
Web: {{site}}</p>
EOT;
