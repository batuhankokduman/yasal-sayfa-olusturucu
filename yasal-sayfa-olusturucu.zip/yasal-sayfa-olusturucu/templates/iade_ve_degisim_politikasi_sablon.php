<?php
return <<<EOT
<h2>CAYMA HAKKI</h2>

TÜKETİCİ’nin hiçbir hukuki ve cezai sorumluluk üstlenmeksizin ve hiçbir gerekçe göstermeksizin malın kendisine veya malın gösterdiği adresteki 3. kişi/kuruluşa tesliminden teslim edildiği tarihten itibaren 15 (on beş) gün içerisinde malı reddederek/iade ederek sözleşmeden cayma hakkının bulunur.

Cayma hakkının kullanılabilmesi için cayma süresi içerisinde SATICI’ya bu hakkın kullanıldığının;

SATICI’nın {{adres}} adresine yazılı olarak veya bir sürekli veri taşıyıcısı ile {{email}} e-posta adresine gönderilecek bir eposta veya web sitesi ya da mobil uygulama üzerinden kolay iade talebi yolu ile bildirilmesi gerekir.

TÜKETİCİ, cayma hakkını kullanırken;

1. TÜKETİCİ’ye veya TÜKETİCİ’nin Teslim Edilecek Kişi olarak tayin ettiği kişiye teslim edilen ürünün faturasını,

2. Kutusu, ambalajı, varsa standart aksesuarları ve ekleri ile birlikte eksiksiz ve hasarsız olarak iade edilecek ürünleri (**)

SATICI’ya teslim edecektir.

(**) Ambalajı açılmış, kullanılmış, tahrip edilmiş vesair şekildeki ürünlerin iadesi kabul edilmez ve bedeli iade edilmez. Müşteri ürünü, kendisine teslim edildiği andaki durumu ile geri vermekle ve kullanım söz konusu ise kullanma dolayısıyla malın ticari değerindeki kaybı tazminle yükümlüdür. Sevkiyat sırasında zarar gördüğü düşünülen ürünler veyahut üründe herhangi bir eksiklik, zarar var ise ürün teslimatı yapan kuryeye iade edilip kargo firmasına tutanak tutturularak ürünün teslim edilmesi gerekmektedir. Zira ürün teslim alındıktan sonra kargo firmasının görevini tam olarak yerine getirdiğini kabul etmiş olursunuz. Bundan dolayı SATICI herhangi bir sorumluluk kabul etmemektedir.

Cayma hakkı kapsamında birden fazla ürünün iade edilmek istenmesi halinde TÜKETİCİ’nin iade etmek istediği tüm ürünleri tek seferde iade ile gerçekleştirmesi zorunludur. İadesi istenen birden fazla ürünün iade süresi içerisinde ayrı ayrı gönderilmesi halinde yalnızca ilk gönderilen ürünün iadesine ilişkin kargo ücreti SATICI’ya ait olup diğer ürünler için kargo ücreti TÜKETİCİ’ye ait olacaktır.

TÜKETİCİ tarafından cayma hakkı çerçevesinde iade edilen ürünün değerinin TÜKETİCİ’nin kusuru nedeniyle azalması veya söz konusu ürünün TÜKETİCİ’nin kusuru sebebiyle telef olması halinde, TÜKETİCİ’nin, SATICI’ya ürünün değerini veya değerindeki azalmayı karşılaması gerekir.

SATICI, cayma bildiriminin kendisine ulaştığı tarihten itibaren en geç 10 (on) gün içerisinde ürün bedeli TÜKETİCİ’nin satın alırken kullandığı ödeme aracına uygun bir şekilde banka hesabına veya kredi kartı hesabına iade edilmesi için ilgili banka nezdinde derhal girişimde bulunur.

Cayma hakkı kapsamında TÜKETİCİ iade edeceği ürün/hizmeti işbu Sözleşmede belirtilen SATICI’nın anlaşmalı kargo şirketi ile SATICI’ya gönderdiği sürece, iade kargo bedeli SATICI’ya aittir. İade için TÜKETİCİ’nin bulunduğu yerde SATICI’nın anlaşmalı kargo şirketi şubesi bulunmaması halinde TÜKETİCİ herhangi bir kargo şirketiyle gönderebilecektir, bu halde kargo bedeli SATICI’ya aittir. TÜKETİCİ’nin iade edeceği malı işbu Sözleşmede belirtilen SATICI’nın anlaşmalı kargo şirketi dışında bir kargo şirketi ile göndermesi halinde, iade kargo bedeli ve malın kargo sürecinde uğrayacağı hasardan SATICI sorumlu değildir. Cayma bildirimi yapılmadan SATICI’ya gönderilen ürünlere ait nakliye ücreti TÜKETİCİ tarafından karşılanacaktır. TÜKETİCİ bu durumda söz konusu nakliye ücretini ödeyeceğini bilir ve kabul eder.

Bu hakkın kullanılması halinde, 3. kişiye veya TÜKETİCİ’ye teslim edilen ürünün SATICI'ya gönderildiğine ilişkin kargo teslim tutanağı örneği ile fatura aslının iadesi zorunludur. Fatura aslı gönderilmez ise KDV ve varsa sair yasal yükümlülükler iade edilemez.

Cayma hakkının kullanılmasıyla beraber TÜKETİCİ ve SATICI arasındaki yan sözleşmeler masraf, tazminat veya cezai şart ödeme yükümlülüğü olmaksızın sona erer.

<h2>CAYMA HAKKININ KULLANILAMAYACAĞI ÜRÜNLER</h2>

TÜKETİCİ aşağıdaki sözleşmelerde cayma hakkını kullanamaz:

a) Fiyatı finansal piyasalardaki dalgalanmalara bağlı olarak değişen ve SATICININ kontrolünde olmayan mal veya hizmetlere ilişkin sözleşmeler

b) TÜKETİCİNİN talepleri veya kişisel ihtiyaçları doğrultusunda hazırlanan ürünlere ilişkin sözleşmeler

c) Çabuk bozulabilen veya son kullanma tarihi geçebilecek malların teslimine ilişkin sözleşmeler

ç) Tesliminden sonra ambalaj, bant, mühür, paket gibi koruyucu unsurları açılmış olan ürünlerden; iade edilmesi sağlık ve hijyen açısından uygun olmayan ürünlere (iç çamaşırı, mayo ve deniz giysileri, kozmetik , parfüm , küpe gibi) ilişkin sözleşmeler.

d) Tesliminden sonra başka ürünlerle karışan ve doğası gereği ayrıştırılması mümkün olmayan ürünlere ilişkin sözleşmeler.

ğ) Elektronik ortamda anında ifa edilen hizmetler ile ALICI’ya anında teslim edilen gayri maddi mallara ilişkin sözleşmeler.

<h2>GENEL HÜKÜMLER</h2>

TÜKETİCİ, SİTE’de ürünün/ürünlerin temel nitelikleri, satış fiyatı, ödemenin şekli, teslimata ilişkin ve diğer ön bilgileri okuyarak bunlardan bilgi sahibi olduğunu ve bu konularda elektronik ortamda gerekli onayı verdiğini beyan eder.

TÜKETİCİ, kredi kartı veya banka kartı aracılığı ile peşin veya taksitli şekilde ödeme yapacak olup; ürünler, SATICI’ya siparişin iletildiği günden itibaren en geç 30 (otuz) gün içerisinde kargo vasıtası ile Teslimat Adresi’ne teslim edilecektir.

Teslim anında TÜKETİCİ’nin adresinde bulunmaması durumunda dahi SATICI edimini tam ve eksiksiz olarak yerine getirmiş olarak kabul edilecektir. Bu nedenle, TÜKETİCİ’nin ürünü geç teslim almasından kaynaklanan her türlü zarar ile ürünün kargo şirketinde beklemiş olması ve/veya kargonun SATICI'ya iade edilmesinden dolayı oluşan giderlere TÜKETİCİ katlanacaktır.

Ürün teslim masrafı olan kargo ücreti, ürün bedeline dâhil olmayıp; TÜKETİCİ tarafından ödenecektir.

TÜKETİCİ’nin kusuru veya ihmali nedeniyle ürünlerin işbu Sözleşmede belirtilen süre içerisinde ve/veya taahhüt edilen şekilde teslim edilememesi halinde SATICI’ya herhangi bir sorumluluk yükletilemez.

TÜKETİCİ’nin bulunduğu yerde kargo firmasının şubesi olmaması durumunda TÜKETİCİ’nin ürünü kargo firmasının SATICI tarafından bildirilen yakın bir diğer şubesinden teslim alması gerekmektedir. İnternet sitesinde "öngörülen teslimat tarihi" şeklinde belirtilen ürünlerin, teslimat tarihi tahmini olarak belirtilmiş olup bu ifade herhangi bir taahhüt içermemektedir.

SATICI, sipariş konusu ürünün tedarikinin imkânsız hale gelmesi durumunda, durumu, sözleşmede belirtilen ürünü teslim etme süresi içerisinde TÜKETİCİ’ye bildirir ve 10 (on) günlük süre içinde toplam bedeli TÜKETİCİ’ye iade eder.

TÜKETİCİ’nin, SATICI tarafından aksi yazılı öngörülmemişse, ürünü teslim almadan önce bedelini tamamen ödemiş olması gerekir. Peşin satışlarda teslimattan önce ürün bedelinin SATICI’ya tamamıyla ödenmediği, taksitli satışlarda ise vadesi gelen taksit tutarı ödenmediği takdirde, SATICI tek taraflı olarak sözleşmeyi iptal edebilir ve ürünü teslim etmeyebilir.

Ürün teslimatı sonrasında TÜKETİCİ’ye ait kredi kartının yetkisiz kişilerce haksız veya hukuka aykırı olarak kullanılması veya herhangi başka bir nedenle ilgili banka veya finans kuruluşunun ürün bedelini SATICI'ya ödememesi veya ödemenin iptali halinde, ürün en geç 7 (yedi) gün içinde TÜKETİCİ tarafından tüm giderleri TÜKETİCİ’ye ait olmak üzere SATICI'ya iade edilir. Bu halde kargo masrafı TÜKETİCİ’ye aittir. SATICI'nın iadeyi kabul etmeksizin ürün bedeli alacağını takip dâhil diğer tüm sözleşmesel-kanuni hakları her halde saklıdır. Herhangi bir sebeple banka ve/veya finans kuruluşu tarafından başarısız kodu gönderilen ancak banka ve/veya finans kuruluşu tarafından SATICI’ya yapılan ödemelere ilişkin SATICI’nın herhangi bir sorumluluğu bulunmayacaktır.

SATICI mücbir sebepler, teslimi engelleyen hava şartları, ulaşımın kesintiye uğraması ve başkaca olağanüstü durumlar nedeni ile sözleşme konusu ürünü/leri süresi içinde teslim edemezsse, bu durumu TÜKETİCİ’ye bildirecektir. Bu takdirde TÜKETİCİ (i) siparişin iptal edilmesini, (ii) sözleşme konusu ürünün/lerin varsa emsali ile değiştirilmesini ve/veya (iii) teslimat süresinin mücbir sebebin/engelleyici durumun ortadan kalkmasına kadar ertelenmesi haklarından birini kullanabilir. TÜKETİCİ’nin siparişi iptal etmesi halinde ödediği toplam tutar 10 (on) gün içinde kendisine nakden ve defaten ödenir. TÜKETİCİ’nin kredi kartı ile yaptığı ödemelerde, ürün/ler tutarı, siparişin TÜKETİCİ tarafından iptal edilmesinden sonra 10 (on) iş günü içerisinde ilgili bankaya iade edilir. Bu tutarın bankaya iadesinden sonra TÜKETİCİ hesaplarına geçmesi tamamen banka işlem süreci ile alakalı olduğundan, TÜKETİCİ, olası gecikmeler için SATICI’nın herhangi bir şekilde müdahalesinin mümkün olamayacağını ve SATICI tarafından kredi kartına iade edilen tutarın banka tarafından TÜKETİCİ hesabına geçirilmesinin alacağı zamanın SATICI’nın sorumluluğunda olmadığını bilmekte ve kabul etmektedir.

<h2>UYUŞMAZLIKLARIN ÇÖZÜMÜNDE YETKİLİ MAHKEME</h2>

İşbu sözleşmeden doğabilecek uyuşmazlıkların çözümünde, Ticaret Bakanlığınca ilan edilen sınıra kadar TÜKETİCİ’nin mal veya hizmeti satın aldığı ve ikametghının bulunduğu yerdeki Tüketici Hakem Heyetleri ile Tüketici Mahkemeleri yetkilidir. 6502 Sayılı Tüketicinin Korunması Hakkında Kanun’un 68. maddesinin 1. fıkrasında belirtilen alt ve üst limitler doğrultusunda tüketici talepleri hakkında ilçe/il tüketici hakem heyetleri yetkilidir.
EOT;
