<?php

class Yso_Admin_UI {
    public static function init() {
        add_menu_page(
            'Yasal Sayfa Oluşturucu',
            'Yasal Sayfalar',
            'manage_options',
            'yso-admin',
            [self::class, 'render_admin_page'],
            'dashicons-clipboard',
            90
        );
        add_action('admin_enqueue_scripts', [self::class, 'load_assets']);
    }

    public static function load_assets() {
        wp_enqueue_style('yso-admin-style', YSO_URL . 'assets/css/admin-style.css');
        wp_enqueue_script('yso-admin-script', YSO_URL . 'assets/js/admin-script.js', ['jquery'], null, true);
    }

 public static function render_admin_page() {
    echo '<div class="wrap">';
    echo '<h1 style="margin-bottom:10px;">📄 Yasal Sayfa Oluşturucu</h1>';

    // Bilgilendirme Metni
    echo '<div style="background:#f9f9f9; border:1px solid #ccc; padding:15px; border-radius:8px; margin-bottom:20px;">
        <p><strong>Bu araç, e-ticaret siteleri için gerekli yasal sayfaları tek tıkla oluşturur.</strong> Sayfalar, firma bilgilerinizle otomatik olarak özelleştirilir. Hangilerini oluşturmak istediğinizi aşağıdan seçebilirsiniz.</p>
    </div>';

    // Sayfa seçme formu
    echo '<form method="post" style="margin-bottom:30px; padding:15px; border:1px solid #ddd; background:#fff; border-radius:8px;">';
    echo '<h2 style="margin-bottom:10px;">🛒 E-Ticaret Sayfaları</h2>';
    echo '<p>Oluşturmak istediğiniz sayfaları seçin:</p>';

    $pages = [
        'mesafeli' => 'Mesafeli Satış Sözleşmesi',
        'iade' => 'İade ve Değişim Politikası',
        'gizlilik' => 'Gizlilik Politikası',
        'kvkk' => 'KVKK Aydınlatma Metni',
        'cerez' => 'Çerez Politikası',
        'kullanim' => 'Kullanım Koşulları'
    ];

    foreach ($pages as $slug => $title) {
        echo '<label style="display:block; margin-bottom:6px;">
            <input type="checkbox" name="yso_pages[]" value="' . esc_attr($slug) . '" ' . $isChecked . '>
            ' . esc_html($title) . '
          </label>';
    }

    submit_button('Seçilen Sayfaları Oluştur');
    echo '</form>';

    // Seçilen sayfaları işleme
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['yso_pages'])) {
        $generator = new Yso_Page_Generator();
        $result = $generator->create_selected_pages($_POST['yso_pages']);
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($result) . '</p></div>';
    }

    // Oluşturulmuş sayfa listesi
    echo '<h2 style="margin-top:40px;">📋 Oluşturulmuş Sayfalar</h2>';
    echo '<table class="widefat striped" style="margin-top:10px;">';
    echo '<thead><tr><th>Sayfa Başlığı</th><th>Permalink</th></tr></thead><tbody>';

    foreach ($pages as $slug => $title) {
        $page = get_page_by_title($title);
        if ($page) {
            echo '<tr>
                    <td>' . esc_html($title) . '</td>
                    <td><a href="' . esc_url(get_permalink($page->ID)) . '" target="_blank">Sayfayı Görüntüle</a></td>
                  </tr>';
        }
    }

    echo '</tbody></table>';
    echo '</div>'; // .wrap
}

}
