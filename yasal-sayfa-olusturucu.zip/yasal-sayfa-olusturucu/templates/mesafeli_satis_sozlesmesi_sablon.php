<?php
return <<<EOT
<h1>Mesafeli Satış Sözleşmesi</h1>
{{firma_adi}} , işbu mesafeli satış kanalı üzerinden satışa sunulan ürünleri yalnızca perakende olarak nihai tüketicilere ulaştırmaktadır/satmaktadır. Perakende satış olmadığı açık olan her türlü sipariş ve genel olarak tüm hileli siparişler natiser tarafından geçersiz sayılacaktır. Tüketici, işbu mesafeli satış kanalı üzerinden yaptığı alışverişin profesyonel/mesleki/ticari faaliyetleri ile ilgili kabul, beyan ve taahhüt eder.

İşbu Mesafeli Satış Sözleşmesi (“Sözleşme”) kapsamında, tüketici (“Alıcı”) ve natiser (“Satıcı”), ayrı ayrı “Taraf”, birlikte “Taraflar” olarak anılacaktır.

<h2>1- Amaç ve Konu</h2>

İşbu Sözleşme, 6502 sayılı Tüketicinin Korunması Hakkında Kanun (“Kanun”) ve 27.1<h3>1.2014 tarihli ve 29188 sayılı Resmi Gazete’de yayımlanan Mesafeli Sözleşmeler Yönetmeliği (“Yönetmelik”) uyarınca, Satıcı’ya ait {{site}} adlı internet sitesi üzerinden (“İnternet Sitesi”) elektronik olarak sipariş edilen ürünlerin satış ve teslimatına ilişkin hüküm ve koşulları hakkında Alıcı’yı bilgilendirmek ve Tarafların karşılıklı hak ve yükümlülüklerini belirlemek amacıyla düzenlenmiştir. İşbu hak ve yükümlülükler, Satıcı tarafından İnternet Sitesi üzerinden satışa sunulan tüm ürünler için geçerli olacaktır:</h3>

Bunun sonucunda, Alıcı tarafından İnternet Sitesi üzerinden satışa sunulan bir ürünün sipariş verilmesi, Alıcı’nın sipariş vermeden önce hakkında bilgi sahibi olduğu işbu Sözleşme’nin tamamının kabul edilmesi anlamına gelir.

Satıcı, işbu genel Sözleşme hükümlerini tek taraflı değiştirme hakkını saklı tutar. Ancak, Alıcı tarafından siparişin verilmesi anında geçerli olan Sözleşme hükümleri, ilgili sipariş için uygulanacaktır.

İşbu Sözleşme, İnternet Sitesi’nde yer alan “Yasal Uyarı ve Kullanım Şartları” ile “Kişisel Verilerin Korunması ve Çerezlere İlişkin Aydınlatma Metni” ile tamamlanmaktadır.

<h2>2- Sözleşme Konusu Ürünün/Ürünlerin Temel Nitelikleri Açıklama Adet KDV Dahil Tutar Toplam Tutar Ürün 2 - - Ürün 1 - - Kargo Bedeli - Ödeme Şekli - Ödenecek Toplam Tutar (KDV Dahil)</h2>

<h2>3- Satıcıya İlişkin Bilgiler</h2>

Ünvanı: {{firma_adi}}

Adresi: {{adres}}

VCKN No: {{vkn}}

Telefon: {{telefon}}

E-posta adresi: destek@{{site}}

Ürün iade adresi: {{adres}}

Alıcı’nın Malı İade Etmesi Halinde Malı Satıcı’ya Göndereceği Anlaşmalı Kargo Şirketleri: Aras Kargo ile yapılan iadelerde ''15040419334799'' cari kodunu kullanarak ve Oplog Lojistik adresine gönderim sağlayabilirsiniz.

Alıcı’ya Satıcı tarafından öneri ve/veya şikayetlerin iletilmesi için işbu Sözleşme’nin 5.10. maddesi uygulanır.

<h2>4- Alıcıya İlişkin Bilgiler Adı Soyadı / Ünvanı : Teslimat Adresi : Tel : E-posta : 5- Genel Hükümler</h2>

<h2>5- Genel Hükümler</h2>

<h3>5.1 Ürün Bedeli</h3>

İnternet Sitesi’nde yer alan ürünlere, Alıcı tarafından ilgili siparişin verildiği anda geçerli olan ve TL cinsinden belirtilen satış fiyatları uygulanır. İnternet Sitesi’nde yer alan ürünlerin satış fiyatı Satıcı tarafından zaman zaman değiştirilebilir. Söz konusu değişiklikler, Alıcı’nın hali hazırda vermiş olduğu siparişi etkilemeyecektir. İnternet Sitesi’nde belirtilen satış fiyatları yalnızca uzaktan mesafeli satışlar için geçerlidir.

İnternet Sitesi’nde belirtilen satış fiyatlarına katma değer vergisi (KDV) dahildir.

Ürünlere yönelik ayrıntılı bilgi olarak İşbu Sözleşme’nin “Sözleşme Konusu Ürünün/Ürünlerin Temel Nitelikleri” başlıklı 2. maddesi uygulanacaktır.

<h3>5.2 Kargo Bedeli ve Kuralları</h3>

İnternet Sitesi’nde belirtilen satış fiyatlarına kargo ücreti dahil değildir; kargo ücreti satın alınan ürünlerin bedeline ayrıca eklenecektir. Kargo ücreti, Alıcı tarafından sipariş kaydedilmeden önce belirtilecektir.

10 kg’ın altında ağırlığa sahip alşverişlerde kargo ücreti 39.90TL olarak belirlenmiştir.

10 kg’ı geçen siparişlerde; 10 kg (ağırlık) ve/veya 10 desi (hacim) üzerinde olan gönderilerin kargo ücreti her bir sepet için özel olarak hesaplanarak sepet adımında bilgi verilerek faturaya yansıtılacaktır.

Satıcı zaman zaman sitede kargo bedava kampanyası yapabilir. Bu kampanyada kargonun ücretsiz kabul edilmesi için ön koşul,  minimum alışveriş tutarının KDV dahil 30 TL’nin üzerinde olmasıdır. Satıcının kampanyalarda dahil olacak ürünleri seçmesi ve müşterileri bilgilendirmesi kendi tasarrufundadır. Alıcı, geçmiş kampanyalara ve/veya promosyonlara ilişkin olarak hak iddia edemez.

Şehir merkezleri dışında kalan bölgelere ve Yurtiçi Türkiye Uzak Bölge Tablosu içerisinde yer alan il, ilçe ve kazalara ve Türkiye sınırları içerisindeki tüm adalara (Bozcaada, Marmara adası, Büyükada, Kınalıada, Heybeliada vb.) kargo gönderimi için ek ücret alınmamaktadır.

Alıcı, siparişinin kargo süreci hakkında aşağıdaki şekilde bilgilendirilecektir;

1.Bilgilendirme: Sipariş kutulanıp kargoya teslim edildiğinde Alıcı’ya sipariş kargoya teslim edildiğine dair maili gönderimi yapılacaktır.

<h2>2. Bilgilendirme: Kargonun Alıcı’ya teslimi için ertesi gün servise çıkılacağına dair, SMS gönderilecektir.</h2>

<h2>3. Bilgilendirme: Kargonun teslim edildi-edilemedi bilgisini vermek için Alıcı’ya gönderilecektir.</h2>

<h3>5.3 Ürün Temel Nitelikleri</h3>

Alıcı, İnternet Sitesi üzerinden farklı kategorilerde yer alan bir veya birden fazla ürün seçebilir.

Satıcı, İnternet Sitesi üzerinden satışa sunulan ürün çeşitliliğini, özellikle tedarikçilerinden kaynaklanan sebeplerden dolayı her zaman için değiştirebilir. Söz konusu değişiklikler Alıcı’nın halihazırda vermiş olduğu siparişi etkilemeyecektir.

İnternet Sitesi üzerinden satışa sunulan ürünler, yürürlükteki Türk mevzuatına uygundur.

Ürünlere yönelik ayrıntılı bilgi olarak İşbu Sözleşme’nin “Sözleşme Konusu Ürünün/Ürünlerin Temel Nitelikleri” başlıklı 2. maddesi uygulanacaktır.

<h3>5.4 Ürün Stok Bilgisi</h3>

Özel teklifler, promosyonlar, kampanyalar veya indirimler belirtilen tarihlerde ve/veya stoklar tükenene kadar geçerli olacaktır. Satıcı, İnternet Sitesi içerisinde verilen puan, indirim gibi özel haklar konusunda sistem kural ihlali ve sistem hatası gibi olası durumlarda sipariş iptali yetkisine sahiptir. Bu konuda Satıcı’dan herhangi bir talepte bulunulamaz.

Ürün stok bilgisi, Alıcı’ya sipariş verdiği anda bildirilir. İşbu bilgilendirmede, teknik sebeplerden dolayı hata veya değişiklik istisnai olarak söz konusu olabilir. Her ne sebeple olursa olsun, Satıcı sipariş iptali yetkisine sahip olup, ürünlerin bir kısmının veya tamamının stoklarda bulunmadığı hallerde, ürünlerin ne zaman temin edileceği veya siparişin tamamını veya bir kısmının iptal edildiği bilgisini sipariş verildikten en az 3 (üç) gün içerisinde  Alıcı’ya bildirir.

İnternet Sitesi bireysel kullanıcı yani nihai tüketiciye hizmet vermesi hedeflenerek planlanmıştır. Bu nedenle sitede bazı ürünlerde satınalma sınırlandırılması yapılmış olabilir. Bu sınırlandırmalar nihai tüketicilerimizin haklarını korumak için yapılmıştır.

Toplu sipariş vermek istenirse musterihizmetleri@{{site}}’ye mail atılarak 2 (iki) gün içerisinde geri dönüş alınabilir.

İnternet sitesinde ve mağazalarda zaman zaman ürünün içeriği ve amacı aynı kalmak koşulu ile ambalaj yenilenmesi yapılmaktadır. Bu nedenle sipariş sırasında internet sitesindeki görüntülenen ambalaj ile müşteriye gönderilen ambalaj tasarımlarında sadece görüntüsel olarak bazı farklılıklar olabilir. Bu farklılıklar cayma hakkı süresi bitiminden sonra söz konusu ürün/ürünler  iade ya da değişime konu olamaz.

<h3>5.5 Sipariş</h3>

Alıcı tarafından sipariş verilmesi, İnternet Sitesi’nde yer alan Yasal Uyarı ve Kullanım Şartları ile Kişisel Verilerin Korunması ve Çerezlere İlişkin Aydınlatma Metni metinlerinin kabulü anlamına gelir.

Tüm siparişler, işbu hükümlere ve İnternet Sitesi’nde yer alan Yasal Uyarı ve Kullanım Şartları ile Kişisel Verilerin Korunması ve Çerezlere İlişkin Aydınlatma Metni metinlerine uygun şekilde işleme alınmaktadır.

Siparişin onaylanmasından önce, Alıcı siparişinin son haline ilişkin detaylarını teyit edebilir ve varsa yanlışlıkları düzeltebilir.

İşbu Sözleşme, Alıcı’nın siparişini, “Ödemenizi onaylayın” veya “Sepetinizi onaylayın” sekmesine tıklayarak onaylaması ile akdedilmiştir. Alıcı’nın, onayladığı söz konusu siparişinin ve özellikle işbu Sözleşme’nin içeriğini ve şartlarını, siparişini onayladığı anda ödeme yükümlülüğü doğacağını ve sipariş ettiği ürünlerin fiyatını, hacmini/ağırlığını, temel özelliklerini, adedini ve teslimat koşullarını bildiği varsayılır. Söz konusu sipariş, Alıcı’nın sağladığı e-posta adresine e-posta gönderilerek teyit edilecektir. Satıcı, işbu teyit e-postasının fiziksel veya elektronik ortamda saklanmasını tavsiye eder. Alıcı’nın e-posta adresine erişimde problem olması veya işbu teyit e-postasının alınamaması halinde, Satıcı’nın sorumluluğu doğmaz. Böyle bir durumda, Satıcı tarafından hukuka uygun nedenlerden dolayı siparişin iptal edilmesi hariç olmak üzere, onaylanan sipariş geçerli kabul edilir. Şüpheye mahal vermemek adına, Alıcı’nın işbu Sözleşme Madde 6’da belirtilen cayma hakkı saklıdır.

Sözleşme konusu ürünün Alıcı’ya teslimatı için, ön bilgilendirme formunun ve işbu Sözleşme’nin Alıcı tarafından elektronik olarak akdedilmiş/onaylanmış ve satış bedelinin tamamının Alıcı tarafından ödenmiş olması şarttır. Herhangi bir nedenle ürün bedelinin tamamı veya bir kısmı ödenmez veya banka kayıtlarında iptal edilir veya İnternet Sitesi’nin kullanımında herhangi bir hileli işlem veya buna teşebbüs tespit edilir ise, Satıcı siparişi ifa etmekten ve siparişin teslimi yükümlülüğünden kurtulmuş kabul edilir.

<h3>5.6 Ödeme</h3>

Alıcı aşağıda belirtilen ödeme yöntemlerini kullanabilecektir. Alıcı, ödeme yapmak için tercih ettiği yöntemler ile ilgili gerekli olan tüm yasal izinlere/statüye sahip olduğunu kabul ve beyan eder.

- Banka Kartları: İnternet Sitesi üzerinden kabul edilen banka kartları: Visa, American Express ve Master Card

<h3>5.8 Teslimat</h3>

Satıcı, Alıcı tarafından verilen siparişi taahhüt ettiği süre içerisinde; en az 2 (iki) işgünü, en fazla siparişin kendisine ulaştığı tarihten itibaren 5 (beş) iş günü içerisinde, Alıcı’nın işbu Sözleşme’nin 4. maddesinde belirttiği teslimat adresine teslim edecektir. Bu süre her halükarda 30 günü geçmeyecektir.

Satıcı, ürünün sağlam, eksiksiz ve siparişte belirtilen niteliklere uygun ve varsa garanti belgeleri ve kullanım kılavuzları ile birlikte teslim edilmesinden sorumludur.

Satıcı mücbir sebepten dolayı ürünü süresi içinde teslim edemez ise, durumu Alıcı’ya en az 3 (üç) gün içerisinde bildirmekle yükümlüdür. Bu takdirde Alıcı, söz konusu siparişinin iptal edilmesini ve sipariş bedelinin iadesini ve/veya sözleşme konusu ürünün varsa emsali ile değiştirilmesini ve/veya teslimat süresinin, engelleyici durumun ortadan kalkmasına kadar ertelenmesi haklarından birini kullanabilir.

<h3>5.9 Ayıplı Ürünler</h3>

Alıcı veya siparişi teslim alan üçüncü kişiler, ürün kutuları ve ambalajları ile ürünün dış görünümünü teslimat sırasında kontrol etmelidir.

Ürün kutusunun açık olması, hasarlı olması veya üzerinde sıvı lekesi bulunması, ürünlerde (eksik veya kırık/hasarlı ürün olması) olağan dışı durum olması veya yanlış ürün gelmiş olması durumlarında Alıcı veya siparişi teslim alan üçüncü kişi, kargoyu teslim almayarak, kargo görevlisine tutanak tutturma ve kargoyu reddetme hakkına sahiptir. Kargo bu olağandışı durumlara rağmen teslim alındı ise aşağıdaki prosedürü izlemelidir;

- İzlenecek Prosedür: Öncelikle lütfen kutuyu/ambalajı (varsa bant ve/veya mührü) açmayınız; aksi halde Alıcı’nın iade talebi karşılanmayacaktır. Alıcı’nın talebi oluşturmak için 14 (on dört) gün içinde İnternet Sitesi Hesabım Bölümüne sipariş numarası ile giriş yaparak iade etmek istediği siparişi ile ilgili İade Formu doldurması gerekmektedir. İade Formunu doldurduktan ve ilgili alana fotoğraf eklendikten sonra söz konusu Alıcı talebi Satıcı’nın İnternet Müşteri İlişkileri Ekibi’ne ulaşacaktır. İnternet Müşteri İlişkileri Ekibi en fazla 2 (iki) gün içerisinde isteği yanıtlayacak ve onay verdiği takdirde iade edilmek istenen siparişi geri aldırmak için Alıcı adresine ücretsiz kargo elemanı yönlendirecektir.

Müşteri İlişkileri onayı olmadan gönderilen kargolar Alıcı’nın sorumluluğundadır.

Söz konusu ürün/ürünler ve Alıcı talebi incelenerek Alıcı’ya en kısa sürede dönüş yapılacaktır. Alıcı talebinin haklı bulunması durumunda iade edilen ürüne ilişkin ödemeler satın alma işlemini yaparken kullanmış olduğu ödeme aracına uygun şekilde ve tek seferde 14 gün içerisinde Alıcı’ya iade edilecektir.

Ayıplı ve hasarlı ürün kategorisine girmeyen ürünlerin iadesi E-Ticaret Deposu üzerinden değişimi ise tüm natiser mağazalarından yapılabilmektedir. İade ve değişim prosedürü için işbu Sözleşme’nin “Cayma Hakkı – İade Prosedürü” başlıklı 6.maddesi uygulanacaktır.

Alıcı veya siparişi teslim alan üçüncü kişi, yukarıda belirtilen olağandışı bir durumla karşılaşmaları halinde, izleyecekleri prosedürü musterihizmetleri@{{site}} adresinden veya {{telefon}} numaralı natiser Müşteri Hizmetlerini arayarak da öğrenebilir.

<h3>5.10 Öneri ve Şikayetler</h3>

Satıcı’nın İnternet Sitesi üzerinden satışa sunulan ürünlere ve ürünlerin kullanımına ilişkin tüm sorular, şikayetler ve tavsiyeler için natiser Müşteri Hizmetleri’ne{{telefon}} numaralı telefondan ulaşılabilir veya İnternet Sitesi üzerinde “Bize Ulaşın” sekmesine tıklayarak mesaj bırakılabilir.

<h2>6- Cayma Hakkı – İade Prosedürü</h2>

Alıcı satın aldığı ürünlere ilişkin olarak, ürünü teslim aldığından veya ürünün gönderildiği üçüncü kişiye teslim edildiği tarihten itibaren 14 (on dört) gün içerisinde, herhangi bir gerekçe göstermeksizin ve/veya cezai şart ödemeksizin cayma hakkını kullanabilmektedir. Yine ilgili ürünün Alıcı’ya teslimine kadar olan süre içinde de Alıcı cayma hakkından yararlanabilecektir.

Alıcı’nın söz konusu bu cayma hakkının kullanılabilmesi için, Yönetmelik’in 15. maddesinin 1. fıkrasının (ç) bendine göre “Tesliminden sonra ambalaj, bant, mühür, paket gibi koruyucu unsurları açılmış olan mallardan; iadesi sağlık ve hijyen açısından uygun olmayanların teslimine ilişkin sözleşmelerde” cayma hakkı kullanılamadığından dolayı; öncelikle ilgili ürünün ambalaj, bant, mühür, paket gibi koruyucu unsurlarının kesinlikle açılmamış olması gerekmektedir, aksi halde Alıcı’nın iade talebi Satıcı tarafından  karşılanmayacaktır.

Talebinizi oluşturmak için 14 (on dört) gün içinde İnternet Sitesi’nde yer alan Hesabım bölümüne sipariş numaranız ile giriş yaparak iade etmek istediğiniz siparişiniz ile ilgili İade Formu doldurunuz ve fotoğraf ekleyiniz.

İade Formunu doldurduktan ve ilgili alana fotoğraf eklendikten sonra Alıcı’nın talebi Satıcı’nın İnternet Müşteri İlişkileri Ekibi’ne ulaşacaktır. Satıcı’nın İnternet Müşteri İlişkileri Ekibi en fazla 2 (iki) iş günü içerisinde isteği yanıtlayacaktır. Alıcı’nın cayma hakkını kullanması durumunda, Satıcı’nın anlaşmalı olduğu kargo şirketi de dahil olmak üzere malın öngörülenin dışında bir taşıyıcıyla iadesi halinde iade masrafları Alıcı tarafından karşılanacaktır.

Kargo Elemanı Alıcı’dan söz konusu ürünü almaya geldiğinde İrsaliye yerine geçen sipariş bilgi fişinin de bulunan iade alanını Alıcı’nın doldurması gerekmektedir. Bu işlem e-ticaret yasaları gereği yapılması gereken bir prosedürdür.

Ürünler, natiser Sipariş Bilgi Fişi (irsaliye yerine geçen) ile birlikte, orijinal ambalajında ve zarar görmemiş şekilde iade edilmelidir. Ürün ile teslim edilen hediye ve aksesuarlar da iade ile birlikte gönderilmelidir.

natiser Müşteri İlişkileri Ekibi’nden onay almadan gönderilen kargolar Alıcı’nın sorumluluğundadır.

Alıcı’nın iade kargosu natiser E-Ticaret Deposu’na teslim edildiğinde Alıcı “iade edilmek istenen ürünlerin teslimatının yapıldığına dair” SMS ile Satıcı tarafından bilgilendirilecektir. Ürünlerin ambalajının açılmadığı, hediye ve tüm aksesuarlarıyla gönderildiği durumlarda;

14 (on dört)  günlük cayma hakkı çerçevesinde değerlendirilen ürün/ürünler doğrudan iade alınacak, satın alma işlemini yaparken Alıcı’nın kullanmış olduğu ödeme aracına uygun şekilde 2 (iki)-10 (on) iş günü içerisinde Alıcı’ya iade edilecektir.

14 (on dört) günlük yasal sınırı geçen iade isteklerinde Alıcı’nın talebininhaklı bulunması durumunda, iade edilen ürüne ilişkin ödemeler satın alma işlemini yaparken Alıcı’nın kullanmış olduğu ödeme aracına uygun şekilde ve tek seferde 14 gün içerisinde Alıcı’ya iade edilecektir.

14 (on dört) günlük cayma hakkı süresini geçen ürün iade istekleri, sadece E-ticaret Müşteri İlişkileri Yönetimi onay verdiği takdirde yapılabilmektedir.

Ürün bedelinin iadesinde bankalardan kaynaklanan gecikme ve aksaklıklardan dolayı Satıcı sorumlu tutulamaz.

İşbu Sözleşme’de belirtilen anlaşmalı kargo şirketleri dışında iade kabul edilmeyecektir.

Satıcı’nın, anlaşmalı olduğu kargo şirketi ile malı kendisinin teslim almaması durumunda, Alıcı’nın, cayma hakkını kullandığına ilişkin bildirimi yönelttiği tarihten itibaren malı Satıcı’ya 14 gün içerisinde geri göndermesi gerekmektedir.

Cayma Hakkı Süresi Dolan Ürünler Hakkındaki Prosedür: Gönderinin teslim edildiği tarihten itibaren 14 (on dört) günü geçmiş olan iade ya da değişim isteklerinde her koşulda kargo Alıcı’ya aittir.

Tesliminden sonra ambalaj, bant, mühür, paket gibi koruyucu unsurları açılmamış, iadesi sağlık ve hijyen açısından uygun ve son kullanma tarihi geçme problemi yaşanmayacak olan ürünlerin iade/değişim işlemleri için, mutlaka e-ticaret müşteri ilişkileri uzmanlarının onayı gereklidir.

İnternet Sitesi üzerindeki “Hesabım/Siparişlerim” altında yer alan İade Formunun Alıcı tarafından doldurulması gerekir.Siparişlerim altında açılan form bölümüne ya da gönderilecek e-posta’ya, Alıcı’nın iade etmek istediği ürünler ile ilgili Alıcı’nın birden fazla fotoğraf eklemesi gereklidir. İade konusunda Alıcı destek almak istediğinde natiser Müşteri Hizmetlerini {{telefon}} no’lu numaradan arayabilir ya da info@{{site}} email adresinden ulaşabilir.

Cayma hakkı süresi dolan ürünlerin süreçleri onaylandığında kargoları istenirse Alıcı’nın kendi seçeceği bir kargo şirketiyle ya da anlaşmalı kargo şirketlerinin natiser’a özel indirimli kargo fiyatları üzerinden yapılabilir. Bu konuda destek almak için ücretsiz müşteri hizmetleri hattımızdan bilgi alabilirsiniz.

a)     Cayma Hakkı Kullanılamayacak Mal/Hizmetlerin Tam Listesi

Fiyatı finansal piyasalardaki dalgalanmalara bağlı olarak değişen ve satıcı veya sağlayıcının kontrolünde olmayan mal veya hizmetlere ilişkin sözleşmeler.
Tüketicinin istekleri veya kişisel ihtiyaçları doğrultusunda hazırlanan mallara ilişkin sözleşmeler.
Çabuk bozulabilen veya son kullanma tarihi geçebilecek malların teslimine ilişkin sözleşmeler.
Tesliminden sonra ambalaj, bant, mühür, paket gibi koruyucu unsurları açılmış olan mallardan; iadesi sağlık ve hijyen açısından uygun olmayanların teslimine ilişkin sözleşmeler.
Tesliminden sonra başka ürünlerle karışan ve doğası gereği ayrıştırılması mümkün olmayan mallara ilişkin sözleşmeler.
Malın tesliminden sonra ambalaj, bant, mühür, paket gibi koruyucu unsurları açılmış olması halinde maddi ortamda sunulan kitap, dijital içerik ve bilgisayar sarf malzemelerine ilişkin sözleşmeler.
Abonelik sözleşmesi kapsamında sağlananlar dışında, gazete ve dergi gibi süreli yayınların teslimine ilişkin sözleşmeler.
Belirli bir tarihte veya dönemde yapılması gereken, konaklama, eşya taşıma, araba kiralama, yiyecek-içecek tedariki ve eğlence veya dinlenme amacıyla yapılan boş zamanın değerlendirilmesine ilişkin sözleşmeler.
Elektronik ortamda anında ifa edilen hizmetler veya tüketiciye anında teslim edilen gayrimaddi mallara ilişkin sözleşmeler.
Cayma hakkı süresi sona ermeden önce, tüketicinin onayı ile ifasına başlanan hizmetlere ilişkin sözleşmeler.
13/10/1983 tarihli ve 2918 sayılı Karayolları Trafik Kanununa göre tescili zorunlu olan taşınırlar ile kayıt veya tescil zorunluluğu bulunan insansız hava araçlarına ilişkin sözleşmeler.
Tüketiciye teslimi yapılmış olan cep telefonu, akıllı saat, tablet ve bilgisayarlara ilişkin sözleşmeler.
Canlı müzayede şeklinde açık artırma yoluyla akdedilen sözleşmeler.
Tanıtma ve kullanma kılavuzunda satıcı veya yetkili servis tarafından kurulum veya montajının yapılacağı belirtilen mallardan kurulum ya da montajı yapılanlara ilişkin sözleşmeler.

Yukarıda da açıklandığı üzere, niteliği itibariyle kozmetik ürünlerde cayma hakkının kullanılması, ürünün ambalajının açılmamış, bozulmamış ve ürünün kullanılmamış olması şartına bağlıdır.

<h2>7- Ürün Değişimi</h2>

İnternet Sitesi’nden Alıcı’nın almış olduğu ürünü kullanmadan ve ambalajı açılmamış şekilde teslim tarihinden itibaren on dört (14) gün içinde tüm natiser mağazalarından değişim/parçalı değişim (faturada yer alan tüm ürünleri yada bir kısmını) yapabilir. Internet Sitesi üzerinden değişim/ parçalı değişim yapılmaz, sadece iade yapılabilir.

natiser mağazalarında değişim işlemi yapılırken, faturada ürünlerin üzerinde olan genel indirim ya da kampanya şartları, ürün detayına dağıtılarak değişim işlemi yapılır. Örneğin; Fatura toplamına %30 indirim uygulanmış ise, değiştirilmek istenen ürün/ürünlerin fiyatları da %30 oranında indirim yapılarak değiştirilen ürünün tutarından düşülür. Fatura tarihinde bazı ürünlerin üzerinde görünen kampanya/indirim koşulları değişim tarihinde değişmiş olabilir. Burada natiser kasa sisteminde o anda tanımlanmış fiyatlar ve kampanya şartları geçerlidir.

<h2>8- Uygulanacak Hukuk ve Uyuşmazlık Çözüm Yeri</h2>

İşbu Sözleşme'nin uygulanmasında ve yorumlanmasında Türk Hukuku uygulanacaktır. İşbu Sözleşme ile ilgili çıkacak ihtilaflarda her yıl Ticaret Bakanlığı tarafından ilan edilen değere kadar Alıcı’nın yerleşim yerindeki veya tüketici işleminin yapıldığı yerdeki il veya ilçe tüketici hakem heyeti, söz konusu değerin üzerindeki ihtilaflarda ise Tüketici Mahkemeleri yetkilidir.

İşbu Sözleşme __/__/__ tarihinde düzenlenmiştir. İşbu belge ile Alıcı, Yönetmeliğin 5. Maddesinde yer alan tüm hususlarda bilgi edindiğini ve siparişi onayladığı ve ödeme yükümü altına gireceğini bildiğini kabul ve beyan etmektedir. Alıcı, işbu Sözleşme’yi elektronik ortamda akdetmekle ürün/ürünlere ve kendisine ait bilgileri edindiğini ve bu bilgilerin doğruluğunu teyit ettiğini kabul ve beyan etmektedir.

TARİH

:

Belirtmek isteriz ki, Mesafeli Sözleşmeler Yönetmeliği’nin “Ön Bilgilendirme” başlıklı 5. Maddesi d fıkrası uyarınca; mal veya hizmetin tüm vergiler dahil toplam fiyatı, niteliği itibariyle önceden hesaplanamıyorsa fiyatın hesaplanma usulü, varsa tüm nakliye, teslim ve benzeri ek masraflar ile bunların önceden hesaplanamaması halinde ek masrafların ödenebileceği bilgisi, açıkça belirtileceği düzenlenmiştir. Bu bulunması zorunlu unsurlardan biridir.

Mesafeli Sözleşmeler Yönetmeliği gereği;

Sipariş konusu mal ya da hizmet ediminin yerine getirilmesinin imkansızlaştığı hallerde satıcı veya sağlayıcının bu durumu öğrendiği tarihten itibaren üç gün içinde tüketiciye yazılı olarak veya kalıcı veri saklayıcısı ile bildirmesi ve varsa teslimat masrafları da dâhil olmak üzere tahsil edilen tüm ödemeleri bildirim tarihinden itibaren en geç on dört gün içinde iade etmesi zorunludur.

Söz konusu formun Sözleşme’de tanımlı olmaması nedeniyle büyük harfle başlaması anlam taşımamaktadır. Ayrıca belirtmek isteriz ki, işbu formun içeriğinin Yönetmelik 5. Maddesine uygun hazırlanması gerekmektedir.

Mesafeli Sözleşmeler Yönetmeliği gereği;

Sipariş konusu mal ya da hizmet ediminin yerine getirilmesinin imkansızlaştığı hallerde satıcı veya sağlayıcının bu durumu öğrendiği tarihten itibaren üç gün içinde tüketiciye yazılı olarak veya kalıcı veri saklayıcısı ile bildirmesi ve varsa teslimat masrafları da dâhil olmak üzere tahsil edilen tüm ödemeleri bildirim tarihinden itibaren en geç on dört gün içinde iade etmesi zorunludur.

Mesafeli Sözleşmeler Yönetmeliği’nin 17. Maddesi aşağıdaki gibidir.

“Zarardan sorumluluk

MADDE 17 – (1) Satıcı, malın tüketici ya da tüketicinin taşıyıcı dışında belirleyeceği üçüncü bir kişiye teslimine kadar oluşan kayıp ve hasarlardan sorumludur.

(2) Tüketicinin, satıcının belirlediği taşıyıcı dışında başka bir taşıyıcı ile malın gönderilmesini talep etmesi durumunda, malın ilgili taşıyıcıya tesliminden itibaren oluşabilecek kayıp ya da hasardan satıcı sorumlu değildir.”

Kanuni yükümlülüğünüz olan cayma hakkının kabulü Yönetmelik’te 9. Maddede 14 gün olarak düzenlenmiştir. Bu maddenin içerdiği sürenin 1 gün farkla burada düzenlenmiş olandan daha lehinize olması nedeniyle 14 gün olarak revize edilmiştir. Teyidinizi rica ederiz. Bunu yapmanızın ayrı bir nedeni var ise 15 gün olarak da tutulmasından bir sakınca yoktur, revizyonu reddedebilirsiniz.

Her bir alıcı için bu tarihin açık bir şekilde açıkça gerektiğini bilgilerinize sunarız.
EOT;
