<?php
return <<<EOT
<h2>Gizlilik Politikası</h2>

<p><strong>{{firma_adi}}</strong> olarak, müşterilerimizin gizliliğini önemsiyor ve 6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında tüm kişisel verileri yasalara uygun şekilde işlemeyi taahhüt ediyoruz.</p>

<h3>1. Toplanan Kişisel Veriler</h3>
<p>Web sitemiz üzerinden yapacağınız alışverişlerde, üyelik işlemlerinde ve iletişim formlarında sizden şu bilgiler toplanabilir:</p>
<ul>
    <li>Ad ve soyad</li>
    <li>Telefon numarası</li>
    <li>E-posta adresi</li>
    <li>Fatura ve teslimat adresi</li>
    <li>T.C. Kimlik numarası (fatura işlemleri için gerektiğinde)</li>
    <li>Ödeme bilgileri (sadece ödeme sağlayıcınız aracılığıyla, tarafımızca saklanmaz)</li>
</ul>

<h3>2. Kişisel Verilerin İşlenme Amaçları</h3>
<p>Toplanan veriler aşağıdaki amaçlarla kullanılabilir:</p>
<ul>
    <li>Ürün ve hizmetleri sunmak</li>
    <li>Siparişlerinizi işlemek ve teslim etmek</li>
    <li>Fatura kesmek</li>
    <li>Size kampanyalar ve promosyonlar hakkında bilgi vermek (onayınız varsa)</li>
    <li>Müşteri hizmetleri süreçlerini yürütmek</li>
</ul>

<h3>3. Verilerin Paylaşımı</h3>
<p>Kişisel verileriniz, aşağıdaki durumlar haricinde üçüncü kişilerle paylaşılmaz:</p>
<ul>
    <li>Yasal yükümlülükler çerçevesinde resmi kurumlara bilgi verilmesi gerektiğinde</li>
    <li>Hizmet aldığımız lojistik ve ödeme kuruluşlarıyla yalnızca hizmet sunumu amacıyla paylaşım</li>
    <li>Yasal danışmanlar ve mali müşavirlerle, yalnızca ilgili hizmetler için paylaşım</li>
</ul>

<h3>4. Veri Güvenliği</h3>
<p><strong>{{firma_adi}}</strong>, verilerinizin güvenliğini sağlamak için gerekli tüm teknik ve idari tedbirleri almaktadır. Web sitemiz <strong>SSL sertifikası</strong> ile korunmakta olup, kişisel verilerinizin gizliliği ve bütünlüğü sağlanmaktadır.</p>

<h3>5. Kişisel Verilerinize İlişkin Haklarınız</h3>
<p>KVKK kapsamında aşağıdaki haklara sahipsiniz:</p>
<ul>
    <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme</li>
    <li>İşlenmişse buna ilişkin bilgi talep etme</li>
    <li>Amacına uygun kullanılıp kullanılmadığını öğrenme</li>
    <li>Yurt içinde veya yurt dışında aktarıldığı 3. kişileri bilme</li>
    <li>Eksik ya da yanlış işlenmişse düzeltilmesini isteme</li>
    <li>Kanuna aykırı işlenmişse silinmesini veya yok edilmesini isteme</li>
    <li>Bu işlemlerin aktarıldığı üçüncü kişilere bildirilmesini isteme</li>
    <li>İtiraz etme ve zararınızın giderilmesini talep etme</li>
</ul>

<h3>6. Çerez (Cookie) Kullanımı</h3>
<p>Web sitemizde kullanıcı deneyimini geliştirmek ve site trafiğini analiz etmek amacıyla çerezler kullanılmaktadır. Tarayıcınızdan çerez ayarlarını değiştirebilir, çerezleri kabul etmeyebilirsiniz.</p>

<h3>7. İletişim</h3>
<p>Kişisel verileriniz ile ilgili her türlü soru ve talep için bize aşağıdaki iletişim bilgilerinden ulaşabilirsiniz:</p>
<ul>
    <li><strong>Firma Adı:</strong> {{firma_adi}}</li>
    <li><strong>Adres:</strong> {{adres}}</li>
    <li><strong>E-posta:</strong> {{email}}</li>
    <li><strong>Telefon:</strong> {{telefon}}</li>
    <li><strong>Web Sitesi:</strong> {{site}}</li>
</ul>

<p>Bu Gizlilik Politikası en son <strong>{date('d.m.Y')}</strong> tarihinde güncellenmiştir.</p>
EOT;
