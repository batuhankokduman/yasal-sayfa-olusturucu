<?php

class Yso_Settings_Page {
    public static function init() {
        add_action('admin_init', [self::class, 'register_settings']);
        add_action('admin_menu', [self::class, 'add_submenu']);
    }

    public static function add_submenu() {
        add_submenu_page(
            'yso-admin',
            'Firma Bilgileri',
            'Firma Bilgileri',
            'manage_options',
            'yso-settings',
            [self::class, 'render_settings_page']
        );
    }

    public static function register_settings() {
        register_setting('yso_settings_group', 'yso_firma_adi');
        register_setting('yso_settings_group', 'yso_vkn');
        register_setting('yso_settings_group', 'yso_vergi_dairesi');
        register_setting('yso_settings_group', 'yso_adres');
        register_setting('yso_settings_group', 'yso_email');
        register_setting('yso_settings_group', 'yso_telefon');
        register_setting('yso_settings_group', 'yso_site');
    }

    public static function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Firma Bilgileri</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('yso_settings_group');
                do_settings_sections('yso_settings_group');
                ?>
                <table class="form-table">
                    <tr><th scope="row">Firma Adı</th><td><input type="text" name="yso_firma_adi" value="<?= esc_attr(get_option('yso_firma_adi')) ?>"></td></tr>
                    <tr><th scope="row">Vergi No (VKN)</th><td><input type="text" name="yso_vkn" value="<?= esc_attr(get_option('yso_vkn')) ?>"></td></tr>
                    <tr><th scope="row">Vergi Dairesi</th><td><input type="text" name="yso_vergi_dairesi" value="<?= esc_attr(get_option('yso_vergi_dairesi')) ?>"></td></tr>
                    <tr><th scope="row">Adres</th><td><textarea name="yso_adres"><?= esc_textarea(get_option('yso_adres')) ?></textarea></td></tr>
                    <tr><th scope="row">E-posta</th><td><input type="email" name="yso_email" value="<?= esc_attr(get_option('yso_email')) ?>"></td></tr>
                    <tr><th scope="row">Telefon</th><td><input type="text" name="yso_telefon" value="<?= esc_attr(get_option('yso_telefon')) ?>"></td></tr>
                    <tr><th scope="row">Web Sitesi</th><td><input type="url" name="yso_site" value="<?= esc_attr(get_option('yso_site')) ?>"></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
